import React from 'react'
import watermark from 'watermark';



function WaterMark() {

  function Mark () { watermark(['/img/shepherd.jpg', '/img/logo.png'])
  .image(watermark.image.lowerRight())
  .then(function (img) {
    document.getElementById('composite-image').appendChild(img);
  });
  }
  return (
    <div>
        <div className={Mark}>
          <h2>Watermark Page</h2>
        </div>

    </div>
  )
}

export default WaterMark;