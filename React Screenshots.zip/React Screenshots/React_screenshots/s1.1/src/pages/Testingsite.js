import React, {useEffect, useState} from 'react'
import axios from 'axios'

function Testingsite() {
    const [count, setCount] = useState(0)
    const [data, setData] = useState([])

    useEffect(() => {
        axios.get('https://jsonplaceholder.typicode.com/photos').then((response) => {
            setData(response.data);
            console.log(response.data);
        })
    },[])

    const IcrementCount = () => {
        setCount(count + 1);
    }

  return (
    <div>
        <h4>Demo Page</h4>
        <p>You click {count} times</p>
        <button onClick={IcrementCount}>Click Me</button>
        {data.map(post => {
            return(
            <div>
                <p>{post.title}</p>
                <img src={post.url} alt='img' />
            </div>
            )
        })}
    </div>
  )
}

export default Testingsite